import pytest
import pandas as pd
from src.data_processor import process_data

def test_process_data_valid():
    data = pd.DataFrame({"stress": [300, 600], "cycles": [5000, 7000]})
    result = process_data(data)
    assert result.equals(data)

def test_process_data_invalid_columns():
    data = pd.DataFrame({"stress": [300], "wrong": [5000]})
    with pytest.raises(ValueError):
        process_data(data)

def test_process_data_negative_values():
    data = pd.DataFrame({"stress": [-300], "cycles": [5000]})
    with pytest.raises(ValueError):
        process_data(data)