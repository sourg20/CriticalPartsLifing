import pytest
import pandas as pd
from src.lifing_model import calculate_fatigue_life

def test_calculate_fatigue_life():
    data = pd.DataFrame({"stress": [300, 600], "cycles": [5000, 7000]})
    results = calculate_fatigue_life(data)
    
    assert "life" in results.columns
    assert results["life"].iloc[0] > results["life"].iloc[1]  # Higher stress = lower life
    assert all(results["life"] > 0)