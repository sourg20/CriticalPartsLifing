from flask import Flask, request, render_template, send_file
import pandas as pd
import os
from data_generator import generate_synthetic_data
from data_processor import process_data
from lifing_model import calculate_fatigue_life
from visualization import plot_lifing_results

app = Flask(__name__, template_folder="C:/Users/souri/critical-parts-lifing-tool/templates")
print("Template folder:", app.template_folder)  # Debug

@app.route("/", methods=["GET", "POST"])
def index():
    plot_path = None
    results_html = None
    error = None

    if request.method == "POST":
        if "file" in request.files and request.files["file"].filename != "":
            file = request.files["file"]
            try:
                data = pd.read_csv(file)
                processed_data = process_data(data)
                results = calculate_fatigue_life(processed_data)
            except Exception as e:
                error = f"Error processing file: {str(e)}"
        else:
            data = generate_synthetic_data()
            processed_data = process_data(data)
            results = calculate_fatigue_life(processed_data)
    else:
        return render_template("index.html", plot_path=None, results_html=None, error=None)

    # Fix plot path: go up one level to root/static/
    plot_path = os.path.join("..", "static", "lifing_plot.png")  # Filesystem path
    plot_lifing_results(results, output_file=plot_path)
    plot_path_for_template = "/static/lifing_plot.png"  # Web path for template
    results_html = results.to_html(index=False)

    return render_template("index.html", plot_path=plot_path_for_template, results_html=results_html, error=error)

@app.route("/download_plot")
def download_plot():
    return send_file("../static/lifing_plot.png", as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)