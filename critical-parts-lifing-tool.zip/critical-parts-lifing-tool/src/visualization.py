import matplotlib.pyplot as plt

def plot_lifing_results(data, output_file="lifing_plot.png"):
    """Generate a scatter plot of fatigue life vs. stress."""
    plt.figure(figsize=(8, 6))
    plt.scatter(data["stress"], data["life"], c=data["cycles"], cmap="viridis")
    plt.colorbar(label="Operational Cycles")
    plt.xlabel("Stress (MPa)")
    plt.ylabel("Fatigue Life (Cycles)")
    plt.title("Critical Parts Lifing Simulation")
    plt.grid(True)
    plt.savefig(output_file)
    plt.close()