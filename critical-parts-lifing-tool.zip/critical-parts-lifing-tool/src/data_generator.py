import numpy as np
import pandas as pd

def generate_synthetic_data(num_samples=10):
    """Generate synthetic operational data for lifing analysis."""
    stress = np.random.uniform(100, 1000, num_samples)  # Stress in MPa
    cycles = np.random.uniform(1000, 10000, num_samples)  # Operational cycles
    return pd.DataFrame({"stress": stress, "cycles": cycles})

