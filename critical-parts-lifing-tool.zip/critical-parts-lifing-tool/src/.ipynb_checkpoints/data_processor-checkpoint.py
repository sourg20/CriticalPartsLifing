import pandas as pd

def process_data(data):
    """Validate and process input data."""
    if not isinstance(data, pd.DataFrame):
        raise ValueError("Input must be a pandas DataFrame")
    
    required_cols = ["stress", "cycles"]
    if not all(col in data.columns for col in required_cols):
        raise ValueError("Data must contain 'stress' and 'cycles' columns")
    
    # Validate data ranges
    if (data["stress"] <= 0).any() or (data["cycles"] <= 0).any():
        raise ValueError("Stress and cycles must be positive")
    if (data["stress"] > 1200).any():  # Arbitrary max stress
        raise ValueError("Stress exceeds maximum allowable value (1200 MPa)")
    
    return data