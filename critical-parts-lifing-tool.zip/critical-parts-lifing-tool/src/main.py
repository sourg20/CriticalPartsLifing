import argparse
import pandas as pd
from data_generator import generate_synthetic_data
from data_processor import process_data
from lifing_model import calculate_fatigue_life
from visualization import plot_lifing_results

def main():
    parser = argparse.ArgumentParser(description="Critical Parts Lifing Simulation Tool")
    parser.add_argument("--synthetic", action="store_true", help="Use synthetic data")
    parser.add_argument("--file", type=str, help="Path to CSV file with stress,cycles columns")
    args = parser.parse_args()

    # Load or generate data
    if args.file:
        try:
            data = pd.read_csv(args.file)
            print(f"Loaded data from {args.file}:")
        except Exception as e:
            print(f"Error reading CSV: {e}")
            return
    else:
        # Default to synthetic data if no file provided
        data = generate_synthetic_data()
        print("Using synthetic data (no file specified):")

    print(data)

    # Process and calculate
    try:
        processed_data = process_data(data)
        results = calculate_fatigue_life(processed_data)
        print("\nResults:")
        print(results)
    except ValueError as e:
        print(f"Data error: {e}")
        return

    # Visualize
    plot_lifing_results(results)
    print("Plot saved as 'lifing_plot.png'")

if __name__ == "__main__":
    main()