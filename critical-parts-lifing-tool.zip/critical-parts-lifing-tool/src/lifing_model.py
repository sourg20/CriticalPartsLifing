def calculate_fatigue_life(data):
    """Calculate remaining fatigue life using a simple S-N curve model."""
    max_cycles = 10000  # Maximum cycles at reference stress
    max_stress = 1200   # Reference stress in MPa
    k = 2               # Material constant (simplified)
    
    # Calculate life using life = max_cycles * (stress / max_stress) ^ (-k)
    data["life"] = max_cycles * (data["stress"] / max_stress) ** (-k)
    return data