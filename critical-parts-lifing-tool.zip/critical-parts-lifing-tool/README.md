# Critical Parts Lifing Simulation Tool

A Python tool to simulate fatigue life of critical engine parts using synthetic data. Includes a CLI and an optional Flask web interface.

## Features
- Generates synthetic data (stress: 100-1000 MPa, cycles: 1000-10000).
- Calculates fatigue life with a simple S-N curve model.
- Visualizes results in a plot (CLI or web).
- Supports CSV uploads via Flask for custom data.

## Installation
1. Clone the repository: